﻿param($installPath, $toolsPath, $package, $project)

Unregister-GlimpseExtension $package